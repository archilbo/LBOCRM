<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title inertia>{{ config('app.name', 'ARCHI LBO OS') }}</title>
    <script>
        window.csrfToken = '{{ csrf_token() }}';
        window.userId = {{ auth()->id() ?? 'null' }};
        window.Laravel = { csrfToken: '{{ csrf_token() }}' };
    </script>
    @routes
    @viteReactRefresh
    @vite(['resources/css/app.css', 'resources/js/app.tsx'])
    @inertiaHead
</head>
<body>
    @inertia
</body>
</html>