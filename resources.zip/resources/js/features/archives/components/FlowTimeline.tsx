import { AlertTriangle, Archive, CheckCircle2, FolderOpen, Plus, RotateCcw, Undo2 } from 'lucide-react';
import type { ArchiveEventRow } from '@/features/archives/types';
import { cn } from '@/lib/cn';

type FlowTimelineProps = {
    events: ArchiveEventRow[];
};

const EVENT_ICONS: Record<string, typeof Plus> = {
    ready: Plus,
    stored: Archive,
    checked_out: FolderOpen,
    returned: Undo2,
    moved: RotateCcw,
    lost: AlertTriangle,
    restored: CheckCircle2,
    note: Plus,
};

const EVENT_COLORS: Record<string, string> = {
    ready: 'text-slate-400 border-slate-400/30 bg-slate-400/10',
    stored: 'text-emerald-400 border-emerald-400/30 bg-emerald-400/10',
    checked_out: 'text-amber-400 border-amber-400/30 bg-amber-400/10',
    returned: 'text-sky-400 border-sky-400/30 bg-sky-400/10',
    moved: 'text-blue-400 border-blue-400/30 bg-blue-400/10',
    lost: 'text-red-400 border-red-400/30 bg-red-400/10',
    restored: 'text-emerald-400 border-emerald-400/30 bg-emerald-400/10',
    note: 'text-[var(--text-muted)] border-[var(--border)] bg-[var(--surface-2)]',
};

export function FlowTimeline({ events }: FlowTimelineProps) {
    if (events.length === 0) {
        return <p className="text-xs text-[var(--text-muted)]">No events yet.</p>;
    }

    return (
        <div className="space-y-0">
            {events.map((event, idx) => {
                const Icon = EVENT_ICONS[event.type] || Plus;
                const color = EVENT_COLORS[event.type] || 'border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-muted)]';

                return (
                    <div key={event.id} className="relative flex gap-3 pb-3 last:pb-0">
                        {idx < events.length - 1 ? (
                            <div className="absolute left-[11px] top-5 bottom-0 w-px bg-[var(--border)]" />
                        ) : null}

                        <span className={cn('relative z-10 flex size-[22px] shrink-0 items-center justify-center rounded-full border', color)}>
                            <Icon size={11} />
                        </span>

                        <div className="min-w-0 flex-1 pt-0.5">
                            <p className="text-xs font-medium capitalize text-[var(--foreground)] leading-tight">
                                {event.type.replace(/_/g, ' ')}
                            </p>
                            <p className="text-[11px] text-[var(--text-muted)] leading-tight">
                                {event.actorName} · {event.createdAt}
                            </p>
                            {event.payload && Object.keys(event.payload).length > 0 ? (
                                <p className="mt-0.5 text-[11px] text-[var(--text-subtle)] leading-tight">
                                    {Object.values(event.payload).filter(v => typeof v === 'string').join(' · ')}
                                </p>
                            ) : null}
                        </div>
                    </div>
                );
            })}
        </div>
    );
}
