import { AlertCircle, Eye, FolderKanban, LogOut, MoreHorizontal, Pencil, Trash2, Undo2 } from 'lucide-react';
import { useState } from 'react';
import type { ArchiveRecordRow, Paginator } from '@/features/archives/types';
import { cn } from '@/lib/cn';

type ArchiveTableProps = {
    archives: ArchiveRecordRow[];
    paginator: Paginator;
    selectedIds: Set<number>;
    onToggleSelect: (id: number) => void;
    onToggleAll: () => void;
    allSelected: boolean;
    onRowClick: (record: ArchiveRecordRow) => void;
    onRowDoubleClick: (record: ArchiveRecordRow) => void;
    onPageChange: (page: number) => void;
    onCheckoutSingle?: (record: ArchiveRecordRow) => void;
    onReturnSingle?: (record: ArchiveRecordRow) => void;
    onEditSingle?: (record: ArchiveRecordRow) => void;
    onDeleteSingle?: (record: ArchiveRecordRow) => void;
};

const STATUS_DOT: Record<string, { dot: string; label: string }> = {
    ready_to_archive: { dot: '○', label: 'Ready' },
    stored: { dot: '●', label: 'Stored' },
    checked_out: { dot: '●', label: 'Out' },
    returned: { dot: '●', label: 'Returned' },
    lost: { dot: '✕', label: 'Lost' },
};

const STATUS_COLORS: Record<string, string> = {
    ready_to_archive: 'text-slate-400',
    stored: 'text-emerald-400',
    checked_out: 'text-amber-400',
    returned: 'text-sky-400',
    lost: 'text-rose-400',
};

export function ArchiveTable({
    archives,
    paginator,
    selectedIds,
    onToggleSelect,
    onToggleAll,
    allSelected,
    onRowClick,
    onRowDoubleClick,
    onPageChange,
    onCheckoutSingle,
    onReturnSingle,
    onEditSingle,
    onDeleteSingle,
}: ArchiveTableProps) {
    const [menuOpen, setMenuOpen] = useState<number | null>(null);

    function closeMenu() { setMenuOpen(null); }

    function statusDisplay(status: string, isOverdue: boolean) {
        const dot = STATUS_DOT[status];
        const color = isOverdue ? 'text-red-400' : STATUS_COLORS[status] || 'text-slate-400';
        return (
            <span className={cn('inline-flex items-center gap-1 text-xs tabular-nums', color)}>
                <span className="text-[10px]">{isOverdue ? '●' : dot?.dot || '○'}</span>
                {isOverdue ? 'Overdue' : dot?.label || status}
            </span>
        );
    }

    return (
        <div className="flex flex-1 flex-col min-h-0">
            <div className="app-scrollbar flex-1 overflow-y-auto">
                <table className="w-full">
                    <thead>
                        <tr className="border-b border-[var(--border)]">
                            <th className="w-7 px-1 py-0">
                                <input
                                    type="checkbox"
                                    checked={allSelected}
                                    onChange={onToggleAll}
                                    className="size-3.5 accent-[var(--accent)]"
                                />
                            </th>
                            <th className="w-28 px-2 py-0 text-left text-[11px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">ARC</th>
                            <th className="px-2 py-0 text-left text-[11px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">Project</th>
                            <th className="w-28 px-2 py-0 text-left text-[11px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">Location</th>
                            <th className="w-16 px-2 py-0 text-left text-[11px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">Status</th>
                            <th className="w-20 px-2 py-0 text-left text-[11px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">Due</th>
                            <th className="w-7 px-1 py-0" />
                        </tr>
                    </thead>
                    <tbody>
                        {archives.map((record) => {
                            const checked = selectedIds.has(record.id);
                            return (
                                <tr
                                    key={record.id}
                                    className={cn(
                                        'h-8 cursor-pointer border-b border-[var(--border)] text-xs transition last:border-0 hover:bg-[var(--surface-2)]',
                                        checked && 'bg-[color-mix(in_srgb,var(--accent)_6%,transparent)]',
                                    )}
                                    onClick={() => onRowClick(record)}
                                    onDoubleClick={() => onRowDoubleClick(record)}
                                >
                                    <td className="w-7 px-1 py-0" onClick={(e) => e.stopPropagation()}>
                                        <input
                                            type="checkbox"
                                            checked={checked}
                                            onChange={() => onToggleSelect(record.id)}
                                            className="size-3.5 accent-[var(--accent)]"
                                        />
                                    </td>
                                    <td className="w-28 px-2 py-0">
                                        <span className="font-mono text-[12px] font-semibold tabular-nums text-[var(--foreground)] leading-tight">
                                            {record.archiveNumber}
                                        </span>
                                    </td>
                                    <td className="px-2 py-0">
                                        <div className="flex items-center gap-1.5 min-w-0">
                                            <FolderKanban size={12} className="shrink-0 text-[var(--text-subtle)]" />
                                            <span className="truncate text-[var(--foreground)] leading-tight">{record.projectObject}</span>
                                        </div>
                                    </td>
                                    <td className="w-28 px-2 py-0">
                                        <span className="font-mono text-[11px] tabular-nums text-[var(--text-muted)] leading-tight">
                                            {record.locationLabel && record.locationLabel !== '-' ? record.locationLabel : '-'}
                                        </span>
                                    </td>
                                    <td className="w-16 px-2 py-0 leading-tight">
                                        {statusDisplay(record.status, record.isOverdue)}
                                    </td>
                                    <td className="w-20 px-2 py-0 leading-tight">
                                        {record.isOverdue ? (
                                            <span className="inline-flex items-center gap-1 text-xs text-red-400">
                                                <AlertCircle size={11} />
                                                {record.dueAt}
                                            </span>
                                        ) : record.dueAt ? (
                                            <span className="text-xs text-[var(--text-muted)] tabular-nums">{record.dueAt}</span>
                                        ) : <span className="text-xs text-[var(--text-subtle)]">—</span>}
                                    </td>
                                    <td className="w-7 px-1 py-0">
                                        <div className="relative">
                                            <button
                                                type="button"
                                                onClick={(e) => { e.stopPropagation(); setMenuOpen(menuOpen === record.id ? null : record.id); }}
                                                className="flex size-6 items-center justify-center rounded text-[var(--text-muted)] hover:bg-[var(--surface-2)] hover:text-[var(--foreground)]"
                                                aria-label="More"
                                            >
                                                <MoreHorizontal size={13} />
                                            </button>
                                            {menuOpen === record.id ? (
                                                <div className="absolute right-0 top-full z-20 min-w-32 rounded-lg border border-[var(--border)] bg-[var(--surface)] py-1 shadow-sm"
                                                    onClick={(e) => e.stopPropagation()}>
                                                    <button type="button" onClick={() => { closeMenu(); onCheckoutSingle?.(record); }}
                                                        className="flex w-full items-center gap-2 px-3 py-1.5 text-xs text-[var(--foreground)] hover:bg-[var(--surface-2)]">
                                                        <LogOut size={12} /> Check out
                                                    </button>
                                                    <button type="button" onClick={() => { closeMenu(); onReturnSingle?.(record); }}
                                                        className="flex w-full items-center gap-2 px-3 py-1.5 text-xs text-[var(--foreground)] hover:bg-[var(--surface-2)]">
                                                        <Undo2 size={12} /> Return
                                                    </button>
                                                    <button type="button" onClick={() => { closeMenu(); onEditSingle?.(record); }}
                                                        className="flex w-full items-center gap-2 px-3 py-1.5 text-xs text-[var(--foreground)] hover:bg-[var(--surface-2)]">
                                                        <Pencil size={12} /> Edit
                                                    </button>
                                                    <button type="button" onClick={() => { closeMenu(); onDeleteSingle?.(record); }}
                                                        className="flex w-full items-center gap-2 px-3 py-1.5 text-xs text-red-400 hover:bg-[var(--surface-2)]">
                                                        <Trash2 size={12} /> Delete
                                                    </button>
                                                </div>
                                            ) : null}
                                        </div>
                                    </td>
                                </tr>
                            );
                        })}
                        {archives.length === 0 ? (
                            <tr>
                                <td colSpan={7} className="h-24 text-center text-xs text-[var(--text-muted)]">No archives found.</td>
                            </tr>
                        ) : null}
                    </tbody>
                </table>
            </div>
            {paginator.lastPage > 1 ? (
                <div className="flex h-8 items-center justify-between border-t border-[var(--border)] px-3 text-xs text-[var(--text-muted)]">
                    <span className="tabular-nums">{paginator.total} total</span>
                    <div className="flex items-center gap-1">
                        {Array.from({ length: paginator.lastPage }, (_, i) => i + 1).map((page) => (
                            <button
                                key={page}
                                type="button"
                                onClick={() => onPageChange(page)}
                                className={cn(
                                    'flex size-6 items-center justify-center rounded tabular-nums transition',
                                    page === paginator.currentPage
                                        ? 'bg-[var(--accent)] text-white font-semibold'
                                        : 'hover:bg-[var(--surface-2)] hover:text-[var(--foreground)]',
                                )}
                            >
                                {page}
                            </button>
                        ))}
                    </div>
                </div>
            ) : null}
        </div>
    );
}
