import { LogOut, MoveRight, Undo2, X } from 'lucide-react';
import { AppButton } from '@/components/ui/AppButton';

type BulkActionBarProps = {
    count: number;
    onCheckout: () => void;
    onReturn: () => void;
    onMove: () => void;
    onClear: () => void;
};

export function BulkActionBar({ count, onCheckout, onReturn, onMove, onClear }: BulkActionBarProps) {
    if (count === 0) return null;

    return (
        <div className="flex h-10 items-center gap-2 border-t border-[var(--accent)]/30 bg-[color-mix(in_srgb,var(--accent)_6%,transparent)] px-3">
            <span className="text-xs font-semibold tabular-nums text-[var(--foreground)]">{count} selected</span>

            <div className="ml-2 flex items-center gap-1">
                <AppButton variant="secondary" size="sm" className="h-7 text-xs" onPress={onCheckout}>
                    <LogOut size={13} /> Check-out
                </AppButton>
                <AppButton variant="secondary" size="sm" className="h-7 text-xs" onPress={onReturn}>
                    <Undo2 size={13} /> Return
                </AppButton>
                <AppButton variant="secondary" size="sm" className="h-7 text-xs" onPress={onMove}>
                    <MoveRight size={13} /> Move
                </AppButton>
            </div>

            <button
                type="button"
                onClick={onClear}
                className="ml-auto flex items-center gap-1 text-xs text-[var(--text-muted)] hover:text-[var(--foreground)]"
            >
                <X size={13} /> Clear
            </button>
        </div>
    );
}
