import { AlertCircle, CalendarClock, ExternalLink, Eye, FolderKanban, MapPin, UserRound } from 'lucide-react';
import type { ArchiveRecordRow } from '@/features/archives/types';
import { StatusPill } from '@/components/ui/StatusPill';
import { cn } from '@/lib/cn';
import { router } from '@inertiajs/react';

type PreviewPanelProps = {
    record: ArchiveRecordRow | null;
};

const STATUS_CONFIG: Record<string, { color: 'success' | 'warning' | 'primary' | 'default' | 'danger'; label: string }> = {
    ready_to_archive: { color: 'default', label: 'Ready' },
    stored: { color: 'success', label: 'Stored' },
    checked_out: { color: 'primary', label: 'Out' },
    returned: { color: 'warning', label: 'Returned' },
    lost: { color: 'danger', label: 'Lost' },
};

export function PreviewPanel({ record }: PreviewPanelProps) {
    if (!record) {
        return (
            <div className="flex h-full items-center justify-center">
                <p className="text-xs text-[var(--text-muted)]">Select an archive to preview</p>
            </div>
        );
    }

    const cfg = record.isOverdue ? { color: 'danger' as const, label: 'Overdue' } : STATUS_CONFIG[record.status] || { color: 'default' as const, label: record.status };

    return (
        <div className="space-y-3">
            <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                    <p className="font-mono text-[13px] font-semibold tabular-nums text-[var(--foreground)]">{record.archiveNumber}</p>
                    <p className="mt-0.5 truncate text-xs text-[var(--text-muted)]">{record.dossierNumber}</p>
                </div>
                <StatusPill label={cfg.label} color={cfg.color} size="sm" />
            </div>

            {record.isOverdue ? (
                <div className="flex items-center gap-1.5 rounded-md border border-red-400/20 bg-red-400/8 px-2 py-1.5 text-xs text-red-400">
                    <AlertCircle size={12} /> Overdue since {record.dueAt}
                </div>
            ) : null}

            <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs">
                    <FolderKanban size={12} className="shrink-0 text-[var(--text-subtle)]" />
                    <span className="truncate text-[var(--foreground)]">{record.projectObject}</span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                    <UserRound size={12} className="shrink-0 text-[var(--text-subtle)]" />
                    <span className="text-[var(--text-muted)]">{record.clientName}</span>
                    <span className="text-[var(--text-subtle)]">({record.clientCin})</span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                    <MapPin size={12} className="shrink-0 text-[var(--text-subtle)]" />
                    <span className="font-mono text-[11px] tabular-nums text-[var(--text-muted)]">{record.locationLabel || '-'}</span>
                </div>
                {record.dueAt ? (
                    <div className="flex items-center gap-2 text-xs">
                        <CalendarClock size={12} className="shrink-0 text-[var(--text-subtle)]" />
                        <span className={cn('tabular-nums', record.isOverdue ? 'text-red-400' : 'text-[var(--text-muted)]')}>
                            Due {record.dueAt}
                        </span>
                    </div>
                ) : null}
            </div>

            <div className="border-t border-[var(--border)] pt-2 text-xs text-[var(--text-subtle)]">
                <p>In: {record.inDate || '-'} · Out: {record.outDate || '-'}</p>
                {record.requestedBy ? <p className="mt-0.5">Req: {record.requestedBy}</p> : null}
            </div>

            {record.notes ? (
                <div className="rounded-md bg-[var(--surface-2)] px-2 py-1.5 text-xs text-[var(--text-muted)] leading-relaxed">
                    {record.notes}
                </div>
            ) : null}

            <button
                type="button"
                onClick={() => router.visit(`/archives/${record.id}`)}
                className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-[var(--border)] py-1.5 text-xs font-medium text-[var(--foreground)] transition hover:bg-[var(--surface-2)]"
            >
                <ExternalLink size={13} /> Open
            </button>
        </div>
    );
}
