import { useState } from 'react';
import { ChevronDown, ChevronRight, MapPin, Package, Plus, Rows3 } from 'lucide-react';
import { cn } from '@/lib/cn';
import type { TreeNode } from '@/features/archives/types';

type StorageTreeProps = {
    tree: TreeNode[];
    selectedRoom: string | null;
    selectedShelf: string | null;
    selectedBox: string | null;
    onSelectRoom: (code: string | null) => void;
    onSelectShelf: (code: string | null) => void;
    onSelectBox: (code: string | null) => void;
};

function FillBar({ fill }: { fill: number }) {
    const color = fill >= 90 ? 'bg-red-400' : fill >= 70 ? 'bg-amber-400' : 'bg-emerald-400';
    return (
        <div className="h-1.5 w-12 rounded-full bg-[var(--surface-2)] overflow-hidden">
            <div className={cn('h-full rounded-full transition-all', color)} style={{ width: `${fill}%` }} />
        </div>
    );
}

export function StorageTree({
    tree,
    selectedRoom,
    selectedShelf,
    selectedBox,
    onSelectRoom,
    onSelectShelf,
    onSelectBox,
}: StorageTreeProps) {
    const [expandedRooms, setExpandedRooms] = useState<Set<number>>(new Set(tree.map((r) => r.id)));
    const [expandedShelves, setExpandedShelves] = useState<Set<number>>(new Set());

    function toggleRoom(id: number) {
        setExpandedRooms((prev) => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id); else next.add(id);
            return next;
        });
    }

    function toggleShelf(id: number) {
        setExpandedShelves((prev) => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id); else next.add(id);
            return next;
        });
    }

    return (
        <div className="space-y-0.5">
            {tree.map((room) => {
                const isRoomSelected = selectedRoom === room.code;
                const isRoomOpen = expandedRooms.has(room.id);

                return (
                    <div key={room.id}>
                        <button
                            type="button"
                            onClick={() => { toggleRoom(room.id); onSelectRoom(isRoomSelected ? null : room.code); }}
                            className={cn(
                                'flex w-full items-center gap-1.5 rounded-md px-2 py-1 text-left text-xs transition',
                                isRoomSelected ? 'bg-[color-mix(in_srgb,var(--accent)_10%,transparent)] text-[var(--accent)]' : 'text-[var(--foreground)] hover:bg-[var(--surface-2)]',
                            )}
                        >
                            {isRoomOpen ? <ChevronDown size={12} className="shrink-0 text-[var(--text-muted)]" /> : <ChevronRight size={12} className="shrink-0 text-[var(--text-muted)]" />}
                            <MapPin size={12} className="shrink-0 text-[var(--text-muted)]" />
                            <span className="font-medium truncate">{room.code}</span>
                            <span className="text-[var(--text-subtle)] ml-auto tabular-nums">{room.name}</span>
                        </button>

                        {isRoomOpen ? (
                            <div className="ml-3 space-y-0.5">
                                {room.shelves?.map((shelf) => {
                                    const isShelfSelected = selectedShelf === shelf.code;
                                    const isShelfOpen = expandedShelves.has(shelf.id);

                                    return (
                                        <div key={shelf.id}>
                                            <button
                                                type="button"
                                                onClick={() => { toggleShelf(shelf.id); onSelectShelf(isShelfSelected ? null : shelf.code); }}
                                                className={cn(
                                                    'flex w-full items-center gap-1.5 rounded-md px-2 py-1 text-left text-xs transition',
                                                    isShelfSelected ? 'bg-[color-mix(in_srgb,var(--accent)_10%,transparent)] text-[var(--accent)]' : 'text-[var(--text-muted)] hover:bg-[var(--surface-2)] hover:text-[var(--foreground)]',
                                                )}
                                            >
                                                {shelf.boxes?.length ? (
                                                    isShelfOpen ? <ChevronDown size={12} className="shrink-0" /> : <ChevronRight size={12} className="shrink-0" />
                                                ) : <span className="w-3 shrink-0" />}
                                                <Rows3 size={12} className="shrink-0" />
                                                <span className="truncate">{shelf.code}</span>
                                                <FillBar fill={shelf.boxes?.reduce((max, b) => Math.max(max, b.fill), 0) ?? 0} />
                                            </button>

                                            {isShelfOpen ? (
                                                <div className="ml-3 space-y-0.5">
                                                    {shelf.boxes?.map((box) => {
                                                        const isBoxSelected = selectedBox === box.code;
                                                        return (
                                                            <button
                                                                key={box.id}
                                                                type="button"
                                                                onClick={(e) => { e.stopPropagation(); onSelectBox(isBoxSelected ? null : box.code); }}
                                                                className={cn(
                                                                    'flex w-full items-center gap-1.5 rounded-md px-2 py-1 text-left text-xs transition',
                                                                    isBoxSelected ? 'bg-[color-mix(in_srgb,var(--accent)_10%,transparent)] text-[var(--accent)]' : 'text-[var(--text-subtle)] hover:bg-[var(--surface-2)] hover:text-[var(--foreground)]',
                                                                )}
                                                            >
                                                                <Package size={12} className="shrink-0" />
                                                                <span className="truncate">{box.code}</span>
                                                                <span className="ml-auto tabular-nums text-[10px]">{box.count}/{box.capacity}</span>
                                                            </button>
                                                        );
                                                    })}
                                                </div>
                                            ) : null}
                                        </div>
                                    );
                                })}
                            </div>
                        ) : null}
                    </div>
                );
            })}
        </div>
    );
}
