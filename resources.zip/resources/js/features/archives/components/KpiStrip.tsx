import { AlertTriangle, Archive, CheckCircle2, FolderOpen, RotateCcw, X } from 'lucide-react';
import { cn } from '@/lib/cn';

type KpiProps = {
    kpis: {
        total: number;
        ready: number;
        stored: number;
        checkedOut: number;
        returned: number;
        overdue: number;
        lost: number;
    };
    activeFilter: string | null;
    onFilter: (key: string | null) => void;
};

const KPI_ITEMS = [
    { key: null, label: 'Total', color: '' },
    { key: 'ready', label: 'Ready', color: 'text-slate-400' },
    { key: 'stored', label: 'Stored', color: 'text-emerald-400' },
    { key: 'checked_out', label: 'Out', color: 'text-amber-400' },
    { key: 'returned', label: 'Returned', color: 'text-sky-400' },
    { key: 'overdue', label: 'Overdue', color: 'text-red-400' },
    { key: 'lost', label: 'Lost', color: 'text-rose-400' },
] as const;

export function KpiStrip({ kpis, activeFilter, onFilter }: KpiProps) {
    return (
        <div className="flex h-8 items-center gap-3 border-b px-3 text-xs">
            {KPI_ITEMS.map((item, i) => {
                const value = item.key ? kpis[item.key as keyof typeof kpis] : kpis.total;
                const isActive = activeFilter === item.key;

                return (
                    <button
                        key={item.key ?? 'total'}
                        type="button"
                        onClick={() => onFilter(isActive ? null : item.key)}
                        className={cn(
                            'tabular-nums transition',
                            isActive ? 'font-semibold text-[var(--accent)]' : item.color || 'text-[var(--text-muted)]',
                            item.key && 'hover:text-[var(--foreground)] cursor-pointer',
                            !item.key && 'cursor-default',
                            item.key === 'overdue' && value > 0 && !isActive && 'text-red-400',
                        )}
                    >
                        {value} {item.label}
                        {i < KPI_ITEMS.length - 1 ? <span className="ml-3 text-[var(--border)]">·</span> : null}
                    </button>
                );
            })}
        </div>
    );
}
