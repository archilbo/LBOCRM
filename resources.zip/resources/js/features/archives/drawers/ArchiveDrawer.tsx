import { FormEvent, useEffect, useMemo, useState } from 'react';
import type { Key } from 'react-aria-components';
import { AppButton } from '@/components/ui/AppButton';
import { AppFormErrorSummary } from '@/components/ui/AppFormErrorSummary';
import { AppDrawer } from '@/components/ui/AppDrawer';
import { AppSelect } from '@/components/ui/AppSelect';
import type { AppSelectOption } from '@/components/ui/AppSelect';
import { AppTextField } from '@/components/ui/AppTextField';
import { AppTextarea } from '@/components/ui/AppTextarea';
import type {
    ArchiveDossierOption,
    ArchiveFormPayload,
    ArchiveRecordRow,
    BoxOption,
    RoomOption,
    ShelfOption,
} from '@/features/archives/types';

type ArchiveDrawerProps = {
    isOpen: boolean;
    mode: 'create' | 'edit';
    archiveRecord: ArchiveRecordRow | null;
    dossiers: ArchiveDossierOption[];
    rooms: RoomOption[];
    shelves: ShelfOption[];
    boxes: BoxOption[];
    onOpenChange: (isOpen: boolean) => void;
    onSubmit: (payload: ArchiveFormPayload) => void;
    errors?: FormErrors;
};

const emptyForm: ArchiveFormPayload = {
    dossierId: '',
    status: 'ready_to_archive',
    room: '',
    shelf: '',
    box: '',
    folder: '',
    inDate: '',
    outDate: '',
    returnedAt: '',
    requestedBy: '',
    notes: '',
    dueAt: '',
};

const statusOptions = [
    { id: 'ready_to_archive', label: 'Ready to archive' },
    { id: 'stored', label: 'Stored' },
    { id: 'checked_out', label: 'Checked out' },
    { id: 'returned', label: 'Returned' },
    { id: 'lost', label: 'Lost' },
];

export function ArchiveDrawer({
    isOpen,
    mode,
    archiveRecord,
    dossiers,
    rooms,
    shelves,
    boxes,
    onOpenChange,
    onSubmit,
    errors = {},
}: ArchiveDrawerProps) {
    const [form, setForm] = useState<ArchiveFormPayload>(emptyForm);

    const dossierOptions = useMemo(
        () =>
            dossiers.map((dossier) => ({
                id: dossier.id,
                label:
                    mode === 'create' && dossier.hasArchiveRecord
                        ? `${dossier.label} - already archived`
                        : dossier.label,
            })),
        [dossiers, mode],
    );

    useEffect(() => {
        if (!isOpen) {
            return;
        }

        if (mode === 'edit' && archiveRecord) {
            setForm({
                dossierId: archiveRecord.dossierId || '',
                status: archiveRecord.status || 'ready_to_archive',
                room: archiveRecord.room || '',
                shelf: archiveRecord.shelf || '',
                box: archiveRecord.box || '',
                folder: archiveRecord.folder || '',
                inDate: archiveRecord.inDate || '',
                outDate: archiveRecord.outDate || '',
                returnedAt: archiveRecord.returnedAt || '',
                requestedBy: archiveRecord.requestedBy || '',
                notes: archiveRecord.notes || '',
                dueAt: archiveRecord.dueAt || '',
            });
            return;
        }

        setForm(emptyForm);
    }, [archiveRecord, isOpen, mode]);

    const roomOptions: AppSelectOption[] = useMemo(() => {
        return rooms.map((room) => ({
            id: room.code,
            label: `${room.code} - ${room.name}`,
        }));
    }, [rooms]);

    const shelfOptions: AppSelectOption[] = useMemo(() => {
        const selectedRoom = rooms.find((r) => r.code === form.room);
        if (!selectedRoom) return [];
        return shelves
            .filter((shelf) => shelf.roomId === selectedRoom.id)
            .map((shelf) => ({
                id: shelf.code,
                label: `${shelf.code} - ${shelf.name}`,
            }));
    }, [rooms, shelves, form.room]);

    const boxOptions: AppSelectOption[] = useMemo(() => {
        const selectedShelf = shelves.find((s) => s.code === form.shelf);
        if (!selectedShelf) return [];
        return boxes
            .filter((box) => box.shelfId === selectedShelf.id)
            .map((box) => ({
                id: box.code,
                label: `${box.code} - ${box.name}`,
            }));
    }, [shelves, boxes, form.shelf]);

    function updateField(field: keyof ArchiveFormPayload, value: string) {
        setForm((current) => ({ ...current, [field]: value }));
    }

    function updateSelect(field: keyof ArchiveFormPayload, value: Key | null) {
        const strVal = value ? String(value) : '';
        setForm((current) => {
            const next = { ...current, [field]: strVal };
            if (field === 'room') {
                next.shelf = '';
                next.box = '';
            }
            if (field === 'shelf') {
                next.box = '';
            }
            return next;
        });
    }

    function handleSubmit(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();
        onSubmit(form);
    }

    const showCheckoutFields = form.status === 'checked_out';

    return (
        <AppDrawer
            isOpen={isOpen}
            onOpenChange={onOpenChange}
            title={mode === 'create' ? 'Create archive record' : 'Edit archive record'}
            description="Save physical archive tracking to the database."
            footer={
                <>
                    <AppButton variant="secondary" onPress={() => onOpenChange(false)}>
                        Cancel
                    </AppButton>

                    <AppButton variant="primary" type="submit" form="archive-form">
                        Save
                    </AppButton>
                </>
            }
        >
            <form id="archive-form" className="space-y-6" onSubmit={handleSubmit}>
                <AppFormErrorSummary errors={errors} />
                <section>
                    <h3 className="mb-3 text-sm font-semibold">Project and status</h3>

                    <div className="grid gap-4">
                        <AppSelect
                            label="Dossier / Project"
                            placeholder="Select dossier"
                            selectedKey={form.dossierId}
                            onSelectionChange={(value) => updateSelect('dossierId', value)}
                            options={dossierOptions}
                        />

                        <AppSelect
                            label="Status"
                            selectedKey={form.status}
                            onSelectionChange={(value) => updateSelect('status', value)}
                            options={statusOptions}
                        />
                    </div>
                </section>

                <section>
                    <h3 className="mb-3 text-sm font-semibold">Physical location</h3>

                    <div className="grid gap-4 md:grid-cols-2">
                        <AppSelect
                            label="Room"
                            placeholder="Select room"
                            selectedKey={form.room || null}
                            onSelectionChange={(value) => updateSelect('room', value)}
                            options={roomOptions}
                        />

                        <AppSelect
                            label="Shelf"
                            placeholder={form.room ? 'Select shelf' : 'Select room first'}
                            selectedKey={form.shelf || null}
                            onSelectionChange={(value) => updateSelect('shelf', value)}
                            options={shelfOptions}
                            isDisabled={!form.room}
                        />

                        <AppSelect
                            label="Box"
                            placeholder={form.shelf ? 'Select box' : 'Select shelf first'}
                            selectedKey={form.box || null}
                            onSelectionChange={(value) => updateSelect('box', value)}
                            options={boxOptions}
                            isDisabled={!form.shelf}
                        />

                        <AppTextField
                            label="Folder"
                            value={form.folder}
                            onChange={(value) => updateField('folder', value)}
                        />
                    </div>
                </section>

                <section>
                    <h3 className="mb-3 text-sm font-semibold">Movement dates</h3>

                    <div className="grid gap-4 md:grid-cols-3">
                        <AppTextField
                            label="In date"
                            value={form.inDate}
                            onChange={(value) => updateField('inDate', value)}
                            placeholder="YYYY-MM-DD"
                        />

                        <AppTextField
                            label="Out date"
                            value={form.outDate}
                            onChange={(value) => updateField('outDate', value)}
                            placeholder="YYYY-MM-DD"
                        />

                        <AppTextField
                            label="Returned at"
                            value={form.returnedAt}
                            onChange={(value) => updateField('returnedAt', value)}
                            placeholder="YYYY-MM-DD"
                        />
                    </div>
                </section>

                {showCheckoutFields ? (
                    <section className="rounded-lg border border-amber-400/30 bg-amber-400/10 p-4">
                        <h3 className="mb-3 text-sm font-semibold text-amber-400">Check-out details</h3>

                        <div className="grid gap-4">
                            <AppTextField
                                label="Due date"
                                value={form.dueAt || ''}
                                onChange={(value) => updateField('dueAt', value)}
                                placeholder="YYYY-MM-DD"
                            />

                            <AppTextField
                                label="Requested by"
                                value={form.requestedBy}
                                onChange={(value) => updateField('requestedBy', value)}
                                placeholder="Name of requester"
                            />
                        </div>
                    </section>
                ) : null}

                <section>
                    <AppTextField
                        label="Requested by"
                        value={form.requestedBy}
                        onChange={(value) => updateField('requestedBy', value)}
                        placeholder="Name of requester"
                    />
                </section>

                <section>
                    <AppTextarea
                        label="Notes"
                        value={form.notes}
                        onChange={(value) => updateField('notes', value)}
                    />
                </section>
            </form>
        </AppDrawer>
    );
}
