import { Head, router } from '@inertiajs/react';
import {
    Plus,
    RefreshCw,
    Search,
    X,
} from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { AppShell } from '@/components/layout/AppShell';
import { AppButton } from '@/components/ui/AppButton';
import { AppModal } from '@/components/ui/AppModal';
import { ArchiveDrawer } from '@/features/archives/drawers/ArchiveDrawer';
import { CheckoutDrawer } from '@/features/archives/drawers/CheckoutDrawer';
import { ReturnDrawer } from '@/features/archives/drawers/ReturnDrawer';
import { MoveDrawer } from '@/features/archives/drawers/MoveDrawer';
import { ArchiveTable } from '@/features/archives/components/ArchiveTable';
import { BulkActionBar } from '@/features/archives/components/BulkActionBar';
import { KpiStrip } from '@/features/archives/components/KpiStrip';
import { MapView } from '@/features/archives/components/MapView';
import { PreviewPanel } from '@/features/archives/components/PreviewPanel';
import { StorageTree } from '@/features/archives/components/StorageTree';
import type {
    ArchiveDossierOption,
    ArchiveFormPayload,
    ArchiveRecordRow,
    ArchivesPageProps,
} from '@/features/archives/types';
import { cn } from '@/lib/cn';

function defaultDue(days = 7): string {
    const d = new Date();
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
}

export default function ArchivesIndex(props: ArchivesPageProps) {
    const [query, setQuery] = useState(props.filters.q || '');
    const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
    const [statusFilter, setStatusFilter] = useState<string | null>(null);

    const [drawerOpen, setDrawerOpen] = useState(false);
    const [drawerMode, setDrawerMode] = useState<'create' | 'edit' | 'batch'>('create');
    const [selectedArchive, setSelectedArchive] = useState<ArchiveRecordRow | null>(null);
    const [previewRecord, setPreviewRecord] = useState<ArchiveRecordRow | null>(props.archives[0] ?? null);
    const [formErrors, setFormErrors] = useState<Record<string, string>>({});
    const [deleteTarget, setDeleteTarget] = useState<ArchiveRecordRow | null>(null);

    const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
    const [selectedRoom, setSelectedRoom] = useState<string | null>(null);
    const [selectedShelf, setSelectedShelf] = useState<string | null>(null);
    const [selectedBox, setSelectedBox] = useState<string | null>(null);

    const [checkoutDrawerOpen, setCheckoutDrawerOpen] = useState(false);
    const [returnDrawerOpen, setReturnDrawerOpen] = useState(false);
    const [moveDrawerOpen, setMoveDrawerOpen] = useState(false);

    const allSelected = props.archives.length > 0 && props.archives.every((r) => selectedIds.has(r.id));

    function handleKpiFilter(key: string | null) {
        setStatusFilter(key);
        router.get('/archives', { ...props.filters, status: key ? [key] : undefined, overdueOnly: key === 'overdue' ? true : undefined }, { preserveScroll: true, preserveState: true });
    }

    function handleSearch(e: React.FormEvent) {
        e.preventDefault();
        router.get('/archives', { ...props.filters, q: query || undefined }, { preserveScroll: true, preserveState: true });
    }

    function handlePageChange(page: number) {
        router.get('/archives', { ...props.filters, page }, { preserveScroll: true, preserveState: true });
    }

    function handleSubmit(payload: ArchiveFormPayload) {
        const backendPayload = {
            dossier_id: payload.dossierId,
            status: payload.status || 'ready_to_archive',
            room: payload.room || null,
            shelf: payload.shelf || null,
            box: payload.box || null,
            folder: payload.folder || null,
            in_date: payload.inDate || null,
            out_date: payload.outDate || null,
            returned_at: payload.returnedAt || null,
            requested_by: payload.requestedBy || null,
            due_at: payload.dueAt || null,
            notes: payload.notes || null,
        };

        if (drawerMode === 'edit' && selectedArchive) {
            router.put(`/archives/${selectedArchive.id}`, backendPayload, {
                preserveScroll: true,
                onSuccess: () => { setDrawerOpen(false); setFormErrors({}); toast.success('Updated.'); },
                onError: (err) => { setFormErrors(err as Record<string, string>); toast.error('Form errors.'); },
            });
            return;
        }

        router.post('/archives', backendPayload, {
            preserveScroll: true,
            onSuccess: () => { setDrawerOpen(false); setFormErrors({}); toast.success('Created.'); },
            onError: (err) => { setFormErrors(err as Record<string, string>); toast.error('Form errors.'); },
        });
    }

    function handleCheckout(data: { archiveIds: number[]; requester: string; dueAt: string; purpose: string }) {
        router.post('/archives/checkout', { archive_ids: data.archiveIds, requested_by: data.requester, due_at: data.dueAt, purpose: data.purpose, notify: true }, {
            preserveScroll: true,
            onSuccess: () => { setSelectedIds(new Set()); toast.success('Checked out.'); },
            onError: () => toast.error('Checkout failed.'),
        });
    }

    function handleReturn(data: { archiveIds: number[]; note: string }) {
        router.post('/archives/return', { archive_ids: data.archiveIds, note: data.note }, {
            preserveScroll: true,
            onSuccess: () => { setSelectedIds(new Set()); toast.success('Returned.'); },
            onError: () => toast.error('Return failed.'),
        });
    }

    function handleMove(data: { archiveIds: number[]; roomCode: string; shelfCode: string; boxCode: string }) {
        router.post('/archives/move', { archive_ids: data.archiveIds, room: data.roomCode, shelf: data.shelfCode, box: data.boxCode }, {
            preserveScroll: true,
            onSuccess: () => { setSelectedIds(new Set()); toast.success('Moved.'); },
            onError: () => toast.error('Move failed.'),
        });
    }

    function openCreateDrawer() {
        setSelectedArchive(null);
        setDrawerMode('create');
        setFormErrors({});
        setDrawerOpen(true);
    }

    function openEditDrawer(record: ArchiveRecordRow) {
        setSelectedArchive(record);
        setDrawerMode('edit');
        setFormErrors({});
        setDrawerOpen(true);
    }

    function handleRowClick(record: ArchiveRecordRow) {
        setPreviewRecord(record);
    }

    function handleRowDoubleClick(record: ArchiveRecordRow) {
        openEditDrawer(record);
    }

    function deleteRecord(record: ArchiveRecordRow) {
        setDeleteTarget(record);
    }

    function confirmDelete() {
        if (!deleteTarget) return;
        router.delete(`/archives/${deleteTarget.id}`, {
            preserveScroll: true,
            onSuccess: () => { setDeleteTarget(null); toast.success('Deleted.'); },
            onError: () => toast.error('Delete failed.'),
        });
    }

    function handleCheckoutSingle(record: ArchiveRecordRow) {
        router.post('/archives/checkout', { archive_ids: [record.id], requested_by: record.requestedBy || '', due_at: defaultDue(), purpose: '' }, {
            preserveScroll: true,
            onSuccess: () => toast.success('Checked out.'),
            onError: () => toast.error('Checkout failed.'),
        });
    }

    function handleReturnSingle(record: ArchiveRecordRow) {
        router.post('/archives/return', { archive_ids: [record.id], note: '' }, {
            preserveScroll: true,
            onSuccess: () => toast.success('Returned.'),
            onError: () => toast.error('Return failed.'),
        });
    }

    return (
        <>
            <Head title="Archives" />
            <AppShell fullBleed>
                <div className="flex h-full min-h-0 flex-col">
                    {/* Title bar — h-10 */}
                    <div className="flex h-10 items-center justify-between border-b px-3">
                        <h1 className="text-lg font-semibold text-[var(--foreground)]">Archives</h1>
                        <div className="flex items-center gap-1 text-[11px] text-[var(--text-muted)]">
                            <kbd className="rounded border border-[var(--border)] px-1">⌘K</kbd>
                            <kbd className="rounded border border-[var(--border)] px-1">N</kbd>
                            <kbd className="rounded border border-[var(--border)] px-1">C</kbd>
                            <kbd className="rounded border border-[var(--border)] px-1">R</kbd>
                            <kbd className="rounded border border-[var(--border)] px-1">M</kbd>
                        </div>
                    </div>

                    {/* Command bar — h-10 */}
                    <form onSubmit={handleSearch} className="flex h-10 items-center gap-2 border-b px-3">
                        <div className="relative flex-1">
                            <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                            <input
                                type="text"
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                placeholder="Search #ARC, project, client, box…"
                                className="h-7 w-full rounded-lg border border-[var(--border)] bg-[var(--surface)] pl-8 pr-7 text-xs text-[var(--foreground)] outline-none placeholder:text-[var(--text-muted)] focus:border-[var(--accent)]"
                            />
                            {query ? (
                                <button type="button" onClick={() => { setQuery(''); router.get('/archives', { ...props.filters, q: undefined }, { preserveScroll: true }); }}
                                    className="absolute right-1.5 top-1/2 -translate-y-1/2 flex size-5 items-center justify-center rounded text-[var(--text-muted)] hover:text-[var(--foreground)]">
                                    <X size={12} />
                                </button>
                            ) : null}
                        </div>
                        <AppButton variant="solid" color="primary" size="sm" className="h-7 text-xs" onPress={openCreateDrawer}>
                            <Plus size={13} /> New
                        </AppButton>
                    </form>

                    {/* KPI strip — h-8 */}
                    <KpiStrip kpis={props.kpis} activeFilter={statusFilter} onFilter={handleKpiFilter} />

                    {/* Three columns */}
                    <div className="flex flex-1 min-h-0">
                        {/* Left — Storage tree, 240px */}
                        <aside className="w-[240px] shrink-0 overflow-y-auto border-r p-2">
                            <StorageTree
                                tree={props.tree}
                                selectedRoom={selectedRoom}
                                selectedShelf={selectedShelf}
                                selectedBox={selectedBox}
                                onSelectRoom={setSelectedRoom}
                                onSelectShelf={setSelectedShelf}
                                onSelectBox={setSelectedBox}
                            />
                        </aside>

                        {/* Center — Work surface */}
                        <main className="flex flex-1 min-w-0 min-h-0 flex-col">
                            {/* Toolbar — h-9 */}
                            <div className="flex h-9 items-center justify-between border-b px-3">
                                <div className="flex items-center gap-1">
                                    <button type="button" onClick={() => setViewMode('list')}
                                        className={cn('rounded-md px-2 py-1 text-xs font-medium transition', viewMode === 'list' ? 'bg-[color-mix(in_srgb,var(--accent)_10%,transparent)] text-[var(--accent)]' : 'text-[var(--text-muted)] hover:text-[var(--foreground)]')}>
                                        List
                                    </button>
                                    <button type="button" onClick={() => setViewMode('map')}
                                        className={cn('rounded-md px-2 py-1 text-xs font-medium transition', viewMode === 'map' ? 'bg-[color-mix(in_srgb,var(--accent)_10%,transparent)] text-[var(--accent)]' : 'text-[var(--text-muted)] hover:text-[var(--foreground)]')}>
                                        Map
                                    </button>
                                </div>
                                <div className="flex items-center gap-1">
                                    <button type="button" onClick={() => router.reload({ preserveScroll: true })}
                                        className="flex size-7 items-center justify-center rounded text-[var(--text-muted)] hover:text-[var(--foreground)]" title="Refresh">
                                        <RefreshCw size={13} />
                                    </button>
                                </div>
                            </div>

                            {viewMode === 'list' ? (
                                <ArchiveTable
                                    archives={props.archives}
                                    paginator={props.paginator}
                                    selectedIds={selectedIds}
                                    onToggleSelect={(id) => setSelectedIds((prev) => { const n = new Set(prev); if (n.has(id)) n.delete(id); else n.add(id); return n; })}
                                    onToggleAll={() => setSelectedIds((prev) => prev.size === props.archives.length ? new Set() : new Set(props.archives.map((r) => r.id)))}
                                    allSelected={allSelected}
                                    onRowClick={handleRowClick}
                                    onRowDoubleClick={handleRowDoubleClick}
                                    onPageChange={handlePageChange}
                                    onCheckoutSingle={handleCheckoutSingle}
                                    onReturnSingle={handleReturnSingle}
                                    onEditSingle={openEditDrawer}
                                    onDeleteSingle={deleteRecord}
                                />
                            ) : (
                                <MapView tree={props.tree} selectedBox={selectedBox} onSelectBox={setSelectedBox} />
                            )}

                            <BulkActionBar
                                count={selectedIds.size}
                                onCheckout={() => setCheckoutDrawerOpen(true)}
                                onReturn={() => setReturnDrawerOpen(true)}
                                onMove={() => setMoveDrawerOpen(true)}
                                onClear={() => setSelectedIds(new Set())}
                            />
                        </main>

                        {/* Right — Preview panel, 320px */}
                        <aside className="w-[320px] shrink-0 overflow-y-auto border-l p-3 hidden lg:block">
                            <PreviewPanel record={previewRecord} />
                        </aside>
                    </div>
                </div>

                {/* Drawers */}
                <ArchiveDrawer
                    isOpen={drawerOpen}
                    mode={drawerMode}
                    archiveRecord={selectedArchive}
                    dossiers={props.dossiers}
                    rooms={props.tree.map((r) => ({ id: r.id, name: r.name, code: r.code }))}
                    shelves={props.tree.flatMap((r) => (r.shelves || []).map((s) => ({ id: s.id, roomId: r.id, name: s.name, code: s.code })))}
                    boxes={props.tree.flatMap((r) => (r.shelves || []).flatMap((s) => (s.boxes || []).map((b) => ({ id: b.id, shelfId: s.id, name: b.name, code: b.code, capacity: b.capacity }))))}
                    onOpenChange={setDrawerOpen}
                    onSubmit={handleSubmit}
                    errors={formErrors}
                />

                <CheckoutDrawer
                    isOpen={checkoutDrawerOpen}
                    onOpenChange={setCheckoutDrawerOpen}
                    archives={props.archives.filter((a) => selectedIds.has(a.id))}
                    onConfirm={handleCheckout}
                />

                <ReturnDrawer
                    isOpen={returnDrawerOpen}
                    onOpenChange={setReturnDrawerOpen}
                    archives={props.archives.filter((a) => selectedIds.has(a.id))}
                    onConfirm={handleReturn}
                />

                <MoveDrawer
                    isOpen={moveDrawerOpen}
                    onOpenChange={setMoveDrawerOpen}
                    archives={props.archives.filter((a) => selectedIds.has(a.id))}
                    tree={props.tree}
                    onConfirm={handleMove}
                />

                {/* Delete confirmation */}
                <AppModal isOpen={!!deleteTarget} onOpenChange={(o) => { if (!o) setDeleteTarget(null); }} title="Delete archive?" size="sm">
                    <p className="mb-4 text-xs text-[var(--text-muted)]">Delete <strong>{deleteTarget?.archiveNumber}</strong>? This cannot be undone.</p>
                    <div className="flex justify-end gap-2">
                        <AppButton variant="bordered" size="sm" onPress={() => setDeleteTarget(null)}>Cancel</AppButton>
                        <AppButton color="danger" variant="solid" size="sm" onPress={confirmDelete}>Delete</AppButton>
                    </div>
                </AppModal>
            </AppShell>
        </>
    );
}
